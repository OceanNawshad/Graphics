#include <cstdio>
#include<stdio.h>
#include<iostream>
#include<GL/gl.h>
#include <GL/glut.h>

using namespace std;

int x,y,nx,ny;
void myDisplay()
{
glClear (GL_COLOR_BUFFER_BIT);
    glColor3ub (128, 128, 128);
    glPointSize(1.0);
    float m=1.0*(ny-y)/(nx-x);

cout<<m<<endl;

for(int i=x;i<nx;i++)
    { glBegin(GL_POINTS);
    cout<<x<<y;
        glVertex2i(x,y);
        x=x+1;
        y=y+m;
         glEnd();
    }

    glBegin(GL_LINES);
    glVertex2i(100,250);
    glVertex2i(200,350);
    glEnd();


    glFlush ();
}

void myInit (void)
{
glClearColor(0.0, 0.0, 0.0, 0.0);
glPointSize(4.0);
glMatrixMode(GL_PROJECTION);
glLoadIdentity();
gluOrtho2D(0.0, 640.0, 0.0, 480.0);
}





int main(int argc, char** argv)
{

 cout<<"please enter starting points"<<endl;
 cin>>x>>y;
 cout<<"please enter ending points"<<endl;
 cin>>nx>>ny;

glutInit(&argc, argv);
glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB);
glutInitWindowSize (640, 480);
glutInitWindowPosition (100, 150);
glutCreateWindow ("");
glutDisplayFunc(myDisplay);
myInit ();
glutMainLoop();
}

